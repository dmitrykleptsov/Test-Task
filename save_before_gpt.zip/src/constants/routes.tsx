export const ROUTES = {
	VIEW: '/',
	MANAGE: '/manage'
}